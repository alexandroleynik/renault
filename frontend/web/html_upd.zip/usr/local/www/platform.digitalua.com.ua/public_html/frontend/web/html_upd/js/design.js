$(document).ready(function() {

	$('.gallbox__list').flexslider({
		controlNav: false,

		start: function(slider) {
			$('.gallbox__count .total').text(slider.count);
		},

		before: function(slider) {
			$('.gallbox__count .index').text(slider.currentSlide + 1);
		},

		after: function(slider) {
			$('.gallbox__count .index').text(slider.currentSlide + 1);
		}
	});



});


$(window).scroll(function() {});
$(window).resize(function() {});
$(window).load(function() {});